<?php
	$pag = "empresa";
?>
<!DOCTYPE html>
<html lang="en">
<?php include("includes/head.php"); ?>
</html>
<body class="empresa">
    
    <?php include("includes/navbar-top.php"); ?>
    
    <?php include("includes/navtopo-logo.php"); ?>
    
    <?php include("includes/navmenu-top.php"); ?>
    
    <div class="container-fluid">
    	<div class="container-fluid-bg-internas"></div>
        <div class="container-fluid-bg-internas-empresa"></div>
        	<div class="hero-unit hero-unit-internas">
            	<div class="container container-internas">
                   	<div class="row-fluid">
                    	<div class="span6">
                            <h3>A Empresa</h3>
                            <p>
                                Melhorar a qualidade de vida das pessoas, acreditando no trabalho em conjunto e oferecendo oportunidade para que aprimorem suas saúdes vitais, este é o conceito inovador da FIVE DIAMONDS. Uma empresa moderna que atua nos três mais promissores mercados do novo milênio: BEM-ESTAR, E-COMMERCE E NETWORK.
                            </p>
                            <p>
                                Seus associados participam do 5D-Club, tendo acesso a produtos exclusivos de Nutrição Celular, desenvolvidos a partir de matérias-primas avançadas, que atendem aos mais elevados padrões internacionais de segurança e qualidade.
                            </p>
                            <p>
                                Os membros interagem em eventos sociais exclusivos e atuam no modelo de negócio mais moderno da economia atual. Um formato que garante todas as facilidades para terem o seu próprio negócio e desfrutarem da vida com toda a liberdade e saúde que merecem.
                            </p>
                        </div>
                    </div>
                    <div class="row-fluid">
                    	<div class="span6">
                            <div class="span4 span4-adaptative">
                            	<h4>Missão</h4>
                                <p>
                                    A Five Diamonds tem como missão inspirar as pessoas a encontrarem um novo caminho para fortalecer suas 5 saúdes vitais, consideradas pilares essenciais para o bem-estar e uma  melhor qualidade de vida.
                                </p>
                            </div>
                            <div class="span1 offset1 bg-missao-itens"></div>
                            <div class="span5">
                                <ul class="list-missao">
                                	<li>
                                    	<span class="bg-diamond"></span>
                                        <span class="item-missao">Física</span>
                                    </li>
                                    <li>
                                    	<span class="bg-diamond"></span>
                                        <span class="item-missao">Mental</span>
                                    </li>
                                    <li>
                                    	<span class="bg-diamond"></span>
                                        <span class="item-missao">Financeira</span>
                                    </li>
                                    <li>
                                    	<span class="bg-diamond"></span>
                                        <span class="item-missao">Familiar</span>
                                    </li>
                                    <li>
                                    	<span class="bg-diamond"></span>
                                        <span class="item-missao">Emocional</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include("includes/rodape.php"); ?>

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script>
	<script src="js/bootstrap.js"></script>
    <script>
		$('.carousel').carousel({
			interval : 15000
		});
	</script>
</body>