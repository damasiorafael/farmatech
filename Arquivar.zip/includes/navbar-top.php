<!-- NAVBARTOP -->
    <div class="navbar">
    	<div class="nav-five navbar-inner">
            <div class="container">
            
                <!-- .btn-navbar is used as the toggle for collapsed navbar content -- >
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
            
                <!-- Be sure to leave the brand out there if you want it shown -->
                
                
                <!-- Everything you want hidden at 940px or less, place within here -->
                <div class="">
                	<form class="navbar-form pull-right form-login form-horizontal" name="login" method="post">
                    	<div class="control-group pull-left">
  							<div class="control-label pull-left">
                                <label for="login" class="pull-left">login:</label>
                            </div>
                            <div class="controls pull-left">
                                <input type="text" class="span1 pull-left" name="login">
                            </div>
                        </div>
                        <div class="control-group pull-left">
  							<div class="control-label pull-left">
                                <label for="senha" class="pull-left">senha:</label>
                            </div>
                            <div class="controls pull-left">
                                <input type="password" class="span1 pull-left" name="senha">
                            </div>
                        </div>
                        <div class="control-group pull-left">
  							<div class="controls">
                    			<button type="submit" class="btn">entrar</button>
                            </div>
                        </div>
                    </form>
                </div>
            
            </div>
        </div>
    </div><!-- NAVBARTOP -->