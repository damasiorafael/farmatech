<!-- NAV-TOPO-LOGO -->
    <div class="container-fluid container-fluid-top">
    	<div class="row-fluid">
        	<div class="hero-unit <?php if($pag != "home"){ ?> hero-unit-no-bg <?php } ?>">
            <?php
				if($pag != "home"){
			?>
            		<div class="container container-internas">
                    	<div class="span12">
                            <a class="brand brand-five brand-five-2" href="index.php" title="Five Diamonds">
                                <span>Five Diamonds</span>
                            </a>
                        </div><!--/span-->
                    </div>
            <?php
            	} else {
			?>
                    <div class="span3">
                        <a class="brand brand-five" href="index.php" title="Five Diamonds">
                            <span>Five Diamonds</span>
                        </a>
                    </div><!--/span-->
                    <div class="span9">
                        <p class="pTitleRid">SAÚDE E VIDA BRASIL</p>
                    </div><!--/span-->
            <?php
				}
			?>
            </div>
        </div>
   	</div><!-- NAV-TOPO-LOGO -->