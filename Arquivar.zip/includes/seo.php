<?php //Exemplo de utiliza��o ?>
<?php //echo $texto['nome-da-pagina']['description'] ?>
<?php
	//header('Content-Type: text/html; charset=iso-8859-1');
	//Global
	$globalTitle											= 'Farmatech';
	$globalDescription										= 'Farmatech';
	$globalKeywords											= 'Farmatech';
	
	//Usado em todas as p�ginas
	$texto['global']['title'] 		  	  					= $globalTitle;
	$texto['global']['description'] 		  				= $globalDescription;
	$texto['global']['keywords'] 		  	  				= $globalKeywords;
?>