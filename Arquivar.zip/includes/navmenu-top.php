<!-- NAV-MENU -->
    <div class="navbar">
    	<div class="nav-five navbar-inner navbar-menu">
            <div class="container">
           		<ul class="nav nav-list">
                    <li <?php if($pag == "empresa"){ ?> class="active" <?php } ?>>
                    	<a href="empresa.php" title="Five Diamonds">Five Diamonds</a>
                    </li>
                    <li <?php if($pag == "nutricao-celular"){ ?> class="active" <?php } ?>>
                    	<a href="nutricao-celular.php" title="Nutrição Celular">Nutrição Celular</a>
                    </li>
                    <li <?php if($pag == "produtos"){ ?> class="active" <?php } ?>>
                    	<a href="produtos.php" title="Produtos">Produtos</a>
                    </li>
                    <li>
                    	<a href="#" title="5D Club">5D Club</a>
                    </li>
                    <li>
                    	<a href="#" title="Faq">Faq</a>
                    </li>
                    <li>
                    	<a href="#" title="Contato">Contato</a>
                    </li>
                </ul>
            </div>
        </div>
    </div><!-- NAV-MENU -->