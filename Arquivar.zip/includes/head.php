<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Five Diamonds 5D - Nutrição Celular">
<meta name="keywords" content="" />
<meta name="author" content="Komeia Interativa">
<meta name="copyright" content="Five Diamonds 5D - Nutrição Celular" />
<meta name="robots" content="index, follow" />
<title>Five Diamonds 5D - Nutrição Celular</title>
<!-- Bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="screen">
<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
<link rel="stylesheet" type="text/css" href="css/my-style.css">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->