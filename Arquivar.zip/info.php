<?php
	
	$pag = "home";
	echo $pag;
	
?>
<?php

	echo "OI";

	phpinfo();

?>