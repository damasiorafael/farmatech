<?php
	$pag = "produtos";
?>
<!DOCTYPE html>
<html lang="en">
<?php include("includes/head.php"); ?>
</html>
<body class="produtos">
    
    <?php include("includes/navbar-top.php"); ?>
    
    <?php include("includes/navtopo-logo.php"); ?>
    
    <?php include("includes/navmenu-top.php"); ?>
    
    <div class="container-fluid">
        <div class="hero-unit hero-unit-internas hero-unit-produtos">
            <div class="container container-internas container-produtos">
                <div class="row-fluid">
                    <ul class="nav-linha-produtos">
                    	<li class="linha-blue">
                        	<a href="#" class="produtos-linha-office" title="Linha Office">
                            	<div class="add-imagem-linha">
                                	<div class="title-linha">
                                    	<div class="enfeite-animate"></div>
                                    	<span class="tx-title-linha">Linha Office</span>
                                    </div>
                                	<img src="img/img-linha-office.jpg" width="306" height="406" alt="Linha Office" />
                                </div>
                                <div class="add-link-linha">
                                	<span class="toggle-color">Energia, Work Performance</span>
                                    <span class="ver-produtos">Ver Produtos</span>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <?php include("includes/rodape.php"); ?>

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script>
	<script src="js/bootstrap.js"></script>
    <script>
		$('.carousel').carousel({
			interval : 15000
		});
	</script>
</body>