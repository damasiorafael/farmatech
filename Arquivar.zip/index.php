<?php
	
	$pag = "home";
	echo $pag;
	
?>
<!DOCTYPE html>
<html lang="en">
<?php
	require_once("includes/head.php");
	echo "OEEEE";
?>
</html>
<body class="home">
    
    <?php include("includes/navbar-top.php"); ?>
    
    <?php include("includes/navtopo-logo.php"); ?>
    
    <?php include("includes/navmenu-top.php"); ?>
    
    <div class="container-fluid container-fluid-carousel container-fluid-home">
    	<div class="row-fluid">
        	<div class="hero-unit">
            	<div class="container">
                	<?php include("includes/carousel.php"); ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php include("includes/rodape.php"); ?>
    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script>
	<script src="js/bootstrap.js"></script>
    <script>
		$('.carousel').carousel({
			interval : 15000
		});
	</script>
</body>